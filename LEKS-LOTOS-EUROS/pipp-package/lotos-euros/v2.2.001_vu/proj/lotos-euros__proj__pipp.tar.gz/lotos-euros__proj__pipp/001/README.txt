Adhoc fixes for PIPP project ...

Added forgotten key to radiation settings.
  rc/lotos-euros-radiation.rc

Fixed wrong level index in radiaton output.
  src/le_output_rad.F90

